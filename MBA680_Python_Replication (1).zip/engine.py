"""Indicator + backtest engine. Every formula mirrors the Pine Script v6 built-ins
(ta.sma, ta.ema, ta.rma-based ta.rsi, ta.macd, ta.bb, ta.stoch, ta.dmi, ta.obv, ta.atr)
so numbers match what TradingView's Strategy Tester reports on the same data."""
import pandas as pd, numpy as np

STOCKS = {
    "RELIANCE": ("Reliance Industries", "Oil, Gas & Conglomerate"),
    "HDFCBANK": ("HDFC Bank", "Private Banking"),
    "INFY": ("Infosys", "IT Services"),
    "ITC": ("ITC", "FMCG"),
    "MARUTI": ("Maruti Suzuki", "Automobiles"),
    "SUNPHARMA": ("Sun Pharmaceutical", "Pharmaceuticals"),
    "LT": ("Larsen & Toubro", "Capital Goods / Infra"),
}
DATA = "/home/claude/tav/data"
START, END = "2015-01-01", "2026-09-25"
CAPITAL, COMM = 1_000_000, 0.0015      # Rs 10 lakh; 0.15% per side = STT 0.1% + stamp/exchange/GST (~0.01-0.02%) + ~0.03% slippage
RF = 0.06                               # idle cash earns ~6% p.a. (approx. 2015-26 average 91-day T-bill); Sharpe is on returns in excess of RF

# Corporate actions the eod2 archive leaves unadjusted (it adjusts splits/bonuses only).
# Factor = ex-date open / previous close for demergers; TERP ratio for the rights issue.
# Matches TradingView's own back-adjustment (verified against TV's RELIANCE prices: ratio
# constant at 1.1120 before May-2020 and 1.1015 after, i.e. exactly these two factors).
CORP_ACTIONS = {
    "RELIANCE": [("2020-05-13", 1 / 1.11195 * 1.10148),   # rights issue 1:15 @ Rs1,257 (pre-bonus)
                 ("2023-07-20", None)],                    # Jio Financial Services demerger
    "ITC":      [("2025-01-06", None)],                    # ITC Hotels demerger
}
def load(sym, warm="2014-01-01", adjust=True):
    d = pd.read_csv(f"{DATA}/{sym.lower()}.csv", parse_dates=["Date"]).sort_values("Date").reset_index(drop=True)
    if adjust:
        for dt, f in CORP_ACTIONS.get(sym.upper(), []):
            i = int(d.Date.searchsorted(pd.Timestamp(dt)))
            if f is None: f = d.Open[i] / d.Close[i - 1]
            for col in ("Open", "High", "Low", "Close"): d.loc[: i - 1, col] *= f
    d = d[d.Date >= warm][["Date", "Open", "High", "Low", "Close", "Volume"]].reset_index(drop=True)
    return d

def rma(x, n):  # Wilder smoothing = Pine ta.rma
    return x.ewm(alpha=1 / n, adjust=False).mean()

def add_ind(d):
    d = d.copy(); c, h, l, v = d.Close, d.High, d.Low, d.Volume
    d["SMA20"], d["SMA50"], d["SMA200"] = c.rolling(20).mean(), c.rolling(50).mean(), c.rolling(200).mean()
    d["EMA9"], d["EMA21"] = c.ewm(span=9, adjust=False).mean(), c.ewm(span=21, adjust=False).mean()
    ch = c.diff(); up, dn = rma(ch.clip(lower=0), 14), rma(-ch.clip(upper=0), 14)
    d["RSI"] = 100 - 100 / (1 + up / dn)
    m = c.ewm(span=12, adjust=False).mean() - c.ewm(span=26, adjust=False).mean()
    d["MACD"], d["MACDsig"] = m, m.ewm(span=9, adjust=False).mean(); d["MACDhist"] = m - d.MACDsig
    sd = c.rolling(20).std(ddof=0)                       # Pine ta.stdev is population sd
    d["BBmid"], d["BBup"], d["BBlo"] = d.SMA20, d.SMA20 + 2 * sd, d.SMA20 - 2 * sd
    d["BBpctB"] = (c - d.BBlo) / (d.BBup - d.BBlo)
    ll, hh = l.rolling(14).min(), h.rolling(14).max()
    d["StochK"] = (100 * (c - ll) / (hh - ll)).rolling(3).mean(); d["StochD"] = d.StochK.rolling(3).mean()
    tr = pd.concat([h - l, (h - c.shift()).abs(), (l - c.shift()).abs()], axis=1).max(axis=1)
    d["ATR"] = rma(tr, 14)
    upm, dnm = h.diff(), -l.diff()
    pdm = np.where((upm > dnm) & (upm > 0), upm, 0.0); ndm = np.where((dnm > upm) & (dnm > 0), dnm, 0.0)
    trr = rma(tr, 14)
    d["PDI"] = 100 * rma(pd.Series(pdm, index=d.index), 14) / trr
    d["NDI"] = 100 * rma(pd.Series(ndm, index=d.index), 14) / trr
    dx = 100 * (d.PDI - d.NDI).abs() / (d.PDI + d.NDI)
    d["ADX"] = rma(dx.fillna(0), 14)
    d["OBV"] = (np.sign(c.diff()).fillna(0) * v).cumsum(); d["OBVema"] = d.OBV.ewm(span=20, adjust=False).mean()
    d["Hi52"] = h.rolling(252).max(); d["VolAvg20"] = v.rolling(20).mean()
    # ---- indicators 9-12 ----
    # 9. Supertrend(10, 3) = Pine ta.supertrend(3, 10): src hl2, ATR = RMA(TR,10); dir -1 = up-trend
    atr10 = rma(tr, 10).values; hl2 = ((h + l) / 2).values; cc = c.values; n = len(d)
    ub = hl2 + 3 * atr10; lb = hl2 - 3 * atr10; st = np.full(n, np.nan); dr = np.ones(n)
    for k in range(1, n):
        if np.isnan(atr10[k - 1]): dr[k] = 1; st[k] = ub[k]; continue
        if not (lb[k] > lb[k - 1] or cc[k - 1] < lb[k - 1]): lb[k] = lb[k - 1]
        if not (ub[k] < ub[k - 1] or cc[k - 1] > ub[k - 1]): ub[k] = ub[k - 1]
        if st[k - 1] == ub[k - 1]: dr[k] = -1 if cc[k] > ub[k] else 1
        else: dr[k] = 1 if cc[k] < lb[k] else -1
        st[k] = lb[k] if dr[k] == -1 else ub[k]
    d["ST"], d["STdir"] = st, dr
    # 10. CCI(20) = Pine ta.cci(hlc3, 20): (src - SMA) / (0.015 * mean abs deviation)
    tp = (h + l + c) / 3; tsma = tp.rolling(20).mean()
    mad = tp.rolling(20).apply(lambda x: np.abs(x - x.mean()).mean(), raw=True)
    d["CCI"] = (tp - tsma) / (0.015 * mad)
    # 11. MFI(14) = Pine ta.mfi(hlc3, 14)
    chg = tp.diff(); mf = v * tp
    upf = mf.where(chg > 0, 0.0).rolling(14).sum(); dnf = mf.where(chg < 0, 0.0).rolling(14).sum()
    d["MFI"] = 100 - 100 / (1 + upf / dnf)
    # 12. Donchian Channel(20): highest high / lowest low of the last 20 bars
    d["DCup"], d["DClo"] = h.rolling(20).max(), l.rolling(20).min(); d["DCmid"] = (d.DCup + d.DClo) / 2
    return d

def xover(a, b): return (a > b) & (a.shift() <= b.shift())
def xunder(a, b): return (a < b) & (a.shift() >= b.shift())

# ---------------- the three horizon strategies ----------------
def sig_A(d):   # 7-day mean reversion in an up-trend
    return (xover(d.RSI, pd.Series(35, index=d.index)) | (xover(d.StochK, d.StochD) & (d.StochK < 20))) & (d.Close > d.SMA200)
def sig_B(d):   # 15-day momentum
    return xover(d.MACD, d.MACDsig) & (d.EMA9 > d.EMA21) & (d.OBV > d.OBVema)
def sig_C(d):   # 60-day trend
    return (xover(d.SMA20, d.SMA50) | xover(d.Close, d.SMA50)) & (d.SMA50 > d.SMA200) & (d.ADX > 20) & (d.PDI > d.NDI)
STRATS = {"A": ("7-day mean reversion", sig_A, 7), "B": ("15-day momentum", sig_B, 15), "C": ("60-day trend", sig_C, 60)}

def backtest(d, signal, hold, start=START, end=END, stop_atr=None, entry_filter=None, delay=0, exit_signal=None, rf=None):
    """Long-only, one position at a time, 100% equity. Signal evaluated on bar close t,
    filled at open t+1+delay (Pine default). Exit after `hold` bars in trade: close order
    issued on the close of bar entry+hold-1, filled at next open. Optional ATR stop."""
    d = d.reset_index(drop=True); sig = signal.reset_index(drop=True).fillna(False).values
    if entry_filter is not None: sig = sig & entry_filter.reset_index(drop=True).fillna(False).values
    xs = exit_signal.reset_index(drop=True).fillna(False).values if exit_signal is not None else np.zeros(len(d), bool)
    g = 1 + (RF if rf is None else rf) / 252        # daily growth of idle cash
    dates = d.Date.values; o, lo, cl = d.Open.values, d.Low.values, d.Close.values; atr = d.ATR.values
    i0 = int(np.searchsorted(dates, np.datetime64(start))); i1 = int(np.searchsorted(dates, np.datetime64(end), "right")) - 1
    eq = CAPITAL; curve = np.full(len(d), np.nan); trades = []; i = i0; pos = None
    while i <= i1:
        if pos is None:
            if i > i0: eq *= g                     # cash earns the T-bill rate while flat
            curve[i] = eq
            if sig[i] and i + 1 + delay <= i1:
                e = i + 1 + delay; px = o[e]; sh = eq * (1 - COMM) / px
                stop = cl[i] - stop_atr * atr[i] if stop_atr else -np.inf   # set on signal bar, as strategy.exit(stop=) in Pine
                pos = dict(e=e, px=px, sh=sh, stop=stop, eq0=eq)
                for k in range(i + 1, e): curve[k] = eq
                i = e; continue
            i += 1; continue
        # in position at bar i
        exit_px = None
        if lo[i] <= pos["stop"]: exit_px = min(o[i], pos["stop"]); xi = i
        elif (i - pos["e"] + 1 >= hold or xs[i]) and i + 1 <= i1: xi = i + 1; exit_px = o[xi]
        elif i == i1: xi = i; exit_px = cl[i]
        if exit_px is None:
            curve[i] = pos["sh"] * cl[i]; i += 1; continue
        if xi > i: curve[i] = pos["sh"] * cl[i]
        eq = pos["sh"] * exit_px * (1 - COMM)
        trades.append(dict(entry=dates[pos["e"]], exit=dates[xi], ep=pos["px"], xp=exit_px,
                           ret=eq / pos["eq0"] - 1, bars=xi - pos["e"]))
        pos = None; i = xi   # flat from bar xi; signal on xi's close may re-enter (as in Pine)
    curve = pd.Series(curve, index=d.Date).iloc[i0:i1 + 1].ffill()
    return curve, pd.DataFrame(trades)

def sharpe_se(sh, yrs):  # Lo (2002) iid standard error of an annualised Sharpe ratio
    return np.sqrt((1 + 0.5 * sh ** 2) / yrs)

def stats(curve, trades, rf=None):
    rf = RF if rf is None else rf
    r = curve.pct_change().dropna() - rf / 252; yrs = (curve.index[-1] - curve.index[0]).days / 365.25
    cagr = (curve.iloc[-1] / curve.iloc[0]) ** (1 / yrs) - 1
    dd = (curve / curve.cummax() - 1).min()
    sh = r.mean() / r.std() * np.sqrt(252) if r.std() > 0 else np.nan
    n = len(trades)
    if n:
        w = trades.ret > 0; pf = trades.ret[w].sum() / -trades.ret[~w].sum() if (~w).any() else np.inf
        expo = trades.bars.sum() / len(curve)
        return dict(Trades=n, Win=w.mean(), AvgTrade=trades.ret.mean(), PF=pf, CAGR=cagr, MaxDD=dd, Sharpe=sh, SharpeSE=sharpe_se(sh, yrs), Exposure=expo, Final=curve.iloc[-1])
    return dict(Trades=0, Win=np.nan, AvgTrade=np.nan, PF=np.nan, CAGR=cagr, MaxDD=dd, Sharpe=sh, SharpeSE=sharpe_se(sh, yrs), Exposure=0, Final=curve.iloc[-1])

def buyhold(d, start=START, end=END):
    x = d.set_index("Date").loc[start:end]
    sh = CAPITAL * (1 - COMM) / x.Open.iloc[0]
    c = sh * x.Close; c.iloc[-1] *= (1 - COMM); return c

def fwd(d, n):  # forward n-bar return from next open (tradeable)
    return d.Open.shift(-1 - n) / d.Open.shift(-1) - 1
