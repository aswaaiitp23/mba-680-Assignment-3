import sys, json, itertools, warnings
sys.path.insert(0, "/home/claude/tav"); warnings.filterwarnings("ignore")
from engine import *
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt, matplotlib.dates as mdates

CH = "/home/claude/tav/charts"
PAL = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300", "#4a3aa7", "#e34948"]
INK, INK2, GRID = "#0b0b0b", "#52514e", "#e6e5e1"
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9, "axes.edgecolor": "#b9b8b2", "axes.labelcolor": INK2,
    "xtick.color": INK2, "ytick.color": INK2, "axes.grid": True, "grid.color": GRID, "grid.linewidth": .6,
    "axes.spines.top": False, "axes.spines.right": False, "lines.linewidth": 1.4, "axes.titleweight": "bold",
    "axes.titlesize": 10.5, "axes.axisbelow": True, "axes.titlelocation": "left", "legend.frameon": False, "figure.dpi": 160})
SYMS = list(STOCKS); COL = dict(zip(SYMS, PAL))
R = {}
def save(fig, name): fig.tight_layout(); fig.savefig(f"{CH}/{name}.png", bbox_inches="tight"); plt.close(fig)

D = {s: add_ind(load(s)) for s in SYMS}
def win(d, a=START, b=END): return d[(d.Date >= a) & (d.Date <= b)]

# ================= 0. universe =================
fig, ax = plt.subplots(figsize=(8, 3.6))
uni = []
for s in SYMS:
    x = win(D[s]).set_index("Date").Close; ax.plot(x / x.iloc[0] * 100, color=COL[s], lw=1.1, label=s)
    bh = stats(buyhold(D[s]), pd.DataFrame()); r = x.pct_change().dropna()
    uni.append(dict(sym=s, name=STOCKS[s][0], sector=STOCKS[s][1], first=str(x.index[0].date()), last=str(x.index[-1].date()),
                    n=len(x), p0=x.iloc[0], p1=x.iloc[-1], cagr=bh["CAGR"], vol=r.std() * np.sqrt(252), dd=bh["MaxDD"], sharpe=bh["Sharpe"]))
ax.set_yscale("log"); ax.set_ylabel("Indexed close (Jan 2015 = 100, log)"); ax.legend(ncol=7, loc="upper center", bbox_to_anchor=(.5, -.1), fontsize=7.5)
ax.set_title("Exhibit 1. The 7-stock NSE Top-100 sample, Jan 2015 – Sep 2026"); save(fig, "01_universe")
R["universe"] = uni

# ================= 1. indicators =================
def bull_states(d):
    return pd.DataFrame({"SMA": d.SMA20 > d.SMA50, "EMA": d.EMA9 > d.EMA21, "RSI": d.RSI > 50, "MACD": d.MACD > d.MACDsig,
        "BB": d.Close > d.BBmid, "Stoch": d.StochK > d.StochD, "ADX": (d.ADX > 20) & (d.PDI > d.NDI), "OBV": d.OBV > d.OBVema,
        "ST": d.STdir == -1, "CCI": d.CCI > 0, "MFI": d.MFI > 50, "DC": d.Close > d.DCmid}).astype(int)
def buy_signals(d):
    return {"SMA 20/50 golden cross": xover(d.SMA20, d.SMA50), "EMA 9/21 bullish cross": xover(d.EMA9, d.EMA21),
        "RSI(14) crosses up 30": xover(d.RSI, pd.Series(30, index=d.index)), "MACD crosses signal": xover(d.MACD, d.MACDsig),
        "Close crosses up lower BB": xover(d.Close, d.BBlo), "Stoch %K>%D below 20": xover(d.StochK, d.StochD) & (d.StochK < 20),
        "ADX>25 with +DI cross": xover(d.PDI, d.NDI) & (d.ADX > 25), "OBV crosses its EMA20": xover(d.OBV, d.OBVema),
        "Supertrend flips up": (d.STdir == -1) & (d.STdir.shift() == 1), "CCI(20) crosses up −100": xover(d.CCI, pd.Series(-100, index=d.index)),
        "MFI(14) crosses up 20": xover(d.MFI, pd.Series(20, index=d.index)), "Donchian 20-day breakout": xover(d.Close, d.DCup.shift())}
sigtab = {}; pooled = {}
for s in SYMS:
    d = D[s]; m = (d.Date >= START); f = fwd(d, 10); base = f[m].mean()
    for k, sg in buy_signals(d).items():
        sel = sg & m & f.notna()
        sigtab.setdefault(k, {})[s] = dict(n=int(sel.sum()), mean=float(f[sel].mean()), hit=float((f[sel] > 0).mean()), excess=float(f[sel].mean() - base))
        pooled.setdefault(k, []).append(f[sel] - base)
R["signal_table"] = sigtab
def _sp(k, v):
    x = pd.concat(v); raw = pd.concat([fwd(D[s_], 10)[buy_signals(D[s_])[k].fillna(False) & (D[s_].Date >= START)] for s_ in SYMS]).dropna()
    se = x.std() / np.sqrt(len(x)); ex = x.mean()
    return dict(n=int(x.size), mean=float(raw.mean()), hit=float((raw > 0).mean()), excess=float(ex), se=float(se), t=float(ex / se), lo=float(ex - 1.96 * se), hi=float(ex + 1.96 * se))
R["signal_pooled"] = {k: _sp(k, v) for k, v in pooled.items()}
uncond = pd.concat([fwd(D[s], 10)[D[s].Date >= START] for s in SYMS]).dropna()
R["uncond10"] = dict(mean=float(uncond.mean()), hit=float((uncond > 0).mean()))

# heatmap of excess 10d return per indicator x stock
fig, ax = plt.subplots(figsize=(8, 4.6))
M = np.array([[sigtab[k][s]["excess"] * 100 for s in SYMS] for k in sigtab])
lim = np.nanmax(np.abs(M)); im = ax.imshow(M, cmap="RdBu", vmin=-lim, vmax=lim, aspect="auto")
ax.set_xticks(range(7), SYMS, fontsize=8); ax.set_yticks(range(len(sigtab)), list(sigtab), fontsize=8); ax.grid(False)
for i in range(len(sigtab)):
    for j in range(7):
        ax.text(j, i, f"{M[i,j]:+.1f}\n(n={sigtab[list(sigtab)[i]][SYMS[j]]['n']})", ha="center", va="center", fontsize=5.6, color="white" if abs(M[i,j]) > 1.4 else INK)
cb = fig.colorbar(im, ax=ax, shrink=.85); cb.set_label("Excess 10-day return vs. unconditional, pp", fontsize=7.5)
ax.set_title("Exhibit 15. Each indicator's buy signal on each stock: excess 10-day forward return"); save(fig, "11_signal_heatmap")

# live dashboard of current state (as of last bar)
last = {s: bull_states(D[s]).iloc[-1].to_dict() for s in SYMS}
R["dashboard"] = {s: {**last[s], "close": float(D[s].Close.iloc[-1]), "rsi": float(D[s].RSI.iloc[-1]), "adx": float(D[s].ADX.iloc[-1]),
                      "score": int(sum(last[s].values()))} for s in SYMS}
R["asof"] = str(D["RELIANCE"].Date.iloc[-1].date())

# indicator correlation (for confirmation bias)
st = pd.concat([bull_states(win(D[s])) for s in SYMS]); C = st.corr()
R["state_corr"] = C.round(3).to_dict()

# per-indicator showcase charts, one stock each (covers all 7 + 1)
def dax(ax):
    ax.xaxis.set_major_locator(mdates.MonthLocator(interval=3)); ax.xaxis.set_major_formatter(mdates.DateFormatter("%b %y"))
showcase = [("SMA", "RELIANCE"), ("EMA", "HDFCBANK"), ("RSI", "INFY"), ("MACD", "ITC"), ("BB", "MARUTI"), ("Stoch", "SUNPHARMA"), ("ADX", "LT"), ("OBV", "RELIANCE"), ("ST", "MARUTI"), ("CCI", "SUNPHARMA"), ("MFI", "ITC"), ("DC", "INFY")]
names = {"SMA": "Simple Moving Average crossover (20/50) + SMA200", "EMA": "Exponential Moving Average crossover (9/21)", "RSI": "Relative Strength Index (14)",
         "MACD": "MACD (12, 26, 9)", "BB": "Bollinger Bands (20, 2σ)", "Stoch": "Stochastic Oscillator (14, 3, 3)", "ADX": "ADX / DMI (14)", "OBV": "On-Balance Volume + EMA(20)", "ST": "Supertrend (10, 3)", "CCI": "Commodity Channel Index (20)", "MFI": "Money Flow Index (14)", "DC": "Donchian Channel (20)"}
for n, (ind, s) in enumerate(showcase):
    d = win(D[s], "2025-03-01"); x = d.Date
    if ind in ("SMA", "EMA", "BB", "ST", "DC"):
        fig, ax = plt.subplots(figsize=(8, 3.3)); ax.plot(x, d.Close, color=INK2, lw=1, label="Close"); a2 = None
        if ind == "SMA":
            ax.plot(x, d.SMA20, color=PAL[0], label="SMA 20"); ax.plot(x, d.SMA50, color=PAL[1], label="SMA 50"); ax.plot(x, d.SMA200, color=PAL[6], lw=1, label="SMA 200")
            g, dc = xover(d.SMA20, d.SMA50), xunder(d.SMA20, d.SMA50)
        elif ind == "EMA":
            ax.plot(x, d.EMA9, color=PAL[0], label="EMA 9"); ax.plot(x, d.EMA21, color=PAL[1], label="EMA 21")
            g, dc = xover(d.EMA9, d.EMA21), xunder(d.EMA9, d.EMA21)
        elif ind == "ST":
            up = d.STdir == -1
            ax.plot(x, d.ST.where(up), color=PAL[5], lw=1.1, label="Supertrend (up-trend)"); ax.plot(x, d.ST.where(~up), color=PAL[7], lw=1.1, label="Supertrend (down-trend)")
            g, dc = (d.STdir == -1) & (d.STdir.shift() == 1), (d.STdir == 1) & (d.STdir.shift() == -1)
        elif ind == "DC":
            ax.fill_between(x, d.DClo, d.DCup, color=PAL[0], alpha=.08, lw=0); ax.plot(x, d.DCup, color=PAL[0], lw=.9, label="20-day high / low")
            ax.plot(x, d.DClo, color=PAL[0], lw=.9); ax.plot(x, d.DCmid, color=PAL[1], lw=.9, ls="--", label="Mid-line")
            g, dc = xover(d.Close, d.DCup.shift()), xunder(d.Close, d.DClo.shift())
        else:
            ax.fill_between(x, d.BBlo, d.BBup, color=PAL[0], alpha=.10, lw=0); ax.plot(x, d.BBup, color=PAL[0], lw=.9, label="Upper/lower band")
            ax.plot(x, d.BBlo, color=PAL[0], lw=.9); ax.plot(x, d.BBmid, color=PAL[1], lw=.9, ls="--", label="Basis (SMA 20)")
            g, dc = xover(d.Close, d.BBlo), xunder(d.Close, d.BBup)
        ax.scatter(x[g], d.Close[g], marker="^", s=46, color=PAL[5], zorder=5, label="Buy signal", edgecolor="white", lw=.8)
        ax.scatter(x[dc], d.Close[dc], marker="v", s=46, color=PAL[7], zorder=5, label="Sell signal", edgecolor="white", lw=.8)
        ax.legend(ncol=6, fontsize=7, loc="upper left"); ax.set_ylabel("₹"); dax(ax)
    else:
        fig, (ax, a2) = plt.subplots(2, 1, figsize=(8, 4.2), sharex=True, gridspec_kw={"height_ratios": [1.5, 1]})
        ax.plot(x, d.Close, color=INK2, lw=1); ax.set_ylabel("₹ close")
        if ind == "RSI":
            a2.plot(x, d.RSI, color=PAL[6]); [a2.axhline(v, color=c, lw=.8, ls="--") for v, c in ((70, PAL[7]), (30, PAL[5]))]; a2.set_ylim(0, 100); a2.set_ylabel("RSI")
            g = xover(d.RSI, pd.Series(30, index=d.index)); dc = xunder(d.RSI, pd.Series(70, index=d.index))
        elif ind == "MACD":
            a2.bar(x, d.MACDhist, color=np.where(d.MACDhist >= 0, PAL[2], PAL[7]), width=1.2); a2.plot(x, d.MACD, color=PAL[0], label="MACD"); a2.plot(x, d.MACDsig, color=PAL[1], label="Signal")
            a2.legend(fontsize=7, ncol=2); g, dc = xover(d.MACD, d.MACDsig), xunder(d.MACD, d.MACDsig)
        elif ind == "Stoch":
            a2.plot(x, d.StochK, color=PAL[0], label="%K"); a2.plot(x, d.StochD, color=PAL[1], label="%D"); [a2.axhline(v, color=INK2, lw=.7, ls="--") for v in (20, 80)]
            a2.set_ylim(0, 100); a2.legend(fontsize=7, ncol=2); g = xover(d.StochK, d.StochD) & (d.StochK < 20); dc = xunder(d.StochK, d.StochD) & (d.StochK > 80)
        elif ind == "ADX":
            a2.plot(x, d.ADX, color=INK, label="ADX"); a2.plot(x, d.PDI, color=PAL[5], label="+DI"); a2.plot(x, d.NDI, color=PAL[7], label="−DI")
            a2.axhline(25, color=INK2, lw=.7, ls="--"); a2.legend(fontsize=7, ncol=3); g = xover(d.PDI, d.NDI) & (d.ADX > 20); dc = xunder(d.PDI, d.NDI) & (d.ADX > 20)
        elif ind == "CCI":
            a2.plot(x, d.CCI, color=PAL[6]); [a2.axhline(v, color=c, lw=.8, ls="--") for v, c in ((100, PAL[7]), (-100, PAL[5]))]; a2.set_ylabel("CCI")
            g = xover(d.CCI, pd.Series(-100, index=d.index)); dc = xunder(d.CCI, pd.Series(100, index=d.index))
        elif ind == "MFI":
            a2.plot(x, d.MFI, color=PAL[6]); [a2.axhline(v, color=c, lw=.8, ls="--") for v, c in ((80, PAL[7]), (20, PAL[5]))]; a2.set_ylim(0, 100); a2.set_ylabel("MFI")
            g = xover(d.MFI, pd.Series(20, index=d.index)); dc = xunder(d.MFI, pd.Series(80, index=d.index))
        else:
            a2.plot(x, d.OBV / 1e6, color=PAL[0], label="OBV (mn shares)"); a2.plot(x, d.OBVema / 1e6, color=PAL[1], label="EMA 20"); a2.legend(fontsize=7, ncol=2)
            g, dc = xover(d.OBV, d.OBVema), xunder(d.OBV, d.OBVema)
        ax.scatter(x[g], d.Close[g], marker="^", s=40, color=PAL[5], zorder=5, edgecolor="white", lw=.8)
        ax.scatter(x[dc], d.Close[dc], marker="v", s=40, color=PAL[7], zorder=5, edgecolor="white", lw=.8); dax(a2)
    ax.set_title(f"Exhibit {n+3}. {names[ind]} on NSE:{s}, Mar 2025 – Sep 2026 (▲ buy / ▼ sell)")
    save(fig, f"{n+3:02d}_ind_{ind}" if n < 8 else f"10{'abcd'[n-8]}_ind_{ind}")

# ================= 2. strategies =================
res = {}; curves = {}; trades_all = {}
for k, (nm, f, h) in STRATS.items():
    for s in SYMS:
        c, t = backtest(D[s], f(D[s]), h); res[(k, s)] = stats(c, t); curves[(k, s)] = c; trades_all[(k, s)] = t
        for lab, a, b in (("IS", "2015-01-01", "2021-12-31"), ("OOS", "2022-01-01", END)):
            c2, t2 = backtest(D[s], f(D[s]), h, a, b); res[(k + lab, s)] = stats(c2, t2)
for s in SYMS:
    curves[("BH", s)] = buyhold(D[s]); res[("BH", s)] = stats(curves[("BH", s)], pd.DataFrame())
def ew(k): return pd.concat([curves[(k, s)] / CAPITAL for s in SYMS], axis=1).ffill().mean(axis=1) * CAPITAL
port = {k: ew(k) for k in ["A", "B", "C", "BH"]}
pstat = {k: stats(port[k], pd.concat([trades_all[(k, s)] for s in SYMS]) if k != "BH" else pd.DataFrame()) for k in port}
R["strat"] = {f"{k}|{s}": v for (k, s), v in res.items()}; R["port"] = pstat
# time-in-market-adjusted: return per year of exposure
fig, ax = plt.subplots(figsize=(8, 3.5))
for k, c, lab in (("BH", INK2, "Buy & hold (EW 7)"), ("A", PAL[0], "A: 7-day mean reversion"), ("B", PAL[1], "B: 15-day momentum"), ("C", PAL[2], "C: 60-day trend")):
    ax.plot(port[k] / CAPITAL, color=c, label=lab, lw=1.6 if k != "BH" else 1.1)
ax.set_ylabel("Growth of ₹1 (equal-weight, 7 stocks)"); ax.legend(ncol=4, fontsize=7.5, loc="upper left")
ax.set_title("Exhibit 17. Equal-weighted 7-stock equity curves, three horizon strategies vs. buy & hold"); save(fig, "13_port_curves")
fig, ax = plt.subplots(figsize=(8, 3.3)); w = .2
for i, k in enumerate(["A", "B", "C", "BH"]):
    ax.bar(np.arange(7) + (i - 1.5) * w, [res[(k, s)]["CAGR"] * 100 for s in SYMS], w * .9, color=[PAL[0], PAL[1], PAL[2], "#b9b8b2"][i],
           label=["A: 7-day", "B: 15-day", "C: 60-day", "Buy & hold"][i])
ax.axhline(0, color=INK2, lw=.8); ax.set_xticks(range(7), SYMS); ax.set_ylabel("CAGR, %"); ax.legend(ncol=4, fontsize=7.5)
ax.set_title("Exhibit 18. CAGR by stock and strategy, Jan 2015 – Sep 2026 (net of 0.05%/side)"); save(fig, "14_cagr_bars")
# trade-example charts, TradingView-style
for k, s, a in (("A", "SUNPHARMA", "2024-01-01"), ("B", "HDFCBANK", "2024-01-01"), ("C", "RELIANCE", "2022-06-01")):
    d = win(D[s], a); t = trades_all[(k, s)]; t = t[t.entry >= np.datetime64(a)]
    fig, ax = plt.subplots(figsize=(8, 3.2)); ax.plot(d.Date, d.Close, color=INK2, lw=1)
    if k == "A": ax.plot(d.Date, d.SMA200, color=PAL[6], lw=.9, label="SMA 200 (trend filter)")
    if k == "B": ax.plot(d.Date, d.EMA9, color=PAL[0], lw=.9, label="EMA 9"); ax.plot(d.Date, d.EMA21, color=PAL[1], lw=.9, label="EMA 21")
    if k == "C": ax.plot(d.Date, d.SMA50, color=PAL[1], lw=.9, label="SMA 50"); ax.plot(d.Date, d.SMA200, color=PAL[6], lw=.9, label="SMA 200")
    for _, r in t.iterrows():
        col = PAL[5] if r.ret > 0 else PAL[7]; ax.axvspan(r.entry, r.exit, color=col, alpha=.10, lw=0)
        ax.scatter([r.entry], [r.ep], marker="^", color=PAL[5], s=36, zorder=5, edgecolor="white", lw=.8)
        ax.scatter([r.exit], [r.xp], marker="v", color=PAL[7], s=36, zorder=5, edgecolor="white", lw=.8)
    ax.legend(fontsize=7, loc="upper left", ncol=3); ax.set_ylabel("₹")
    num = {"A": 15, "B": 16, "C": 17}[k]
    ax.set_title(f"Exhibit {num+4}. Strategy {k} ({STRATS[k][0]}) trades on NSE:{s} — green band = winning trade, red = losing")
    save(fig, f"{num}_trades_{k}")
    R.setdefault("example", {})[k] = dict(sym=s, n=len(t), win=float((t.ret > 0).mean()) if len(t) else None)

# ================= 3. biases =================
B = {}
# (a) Confirmation: redundant vs independent confirmation
def pool_fwd(cond_fn, n=10):
    out = []
    for s in SYMS:
        d = D[s]; m = d.Date >= START; c = cond_fn(d).fillna(False) & m; out.append(fwd(d, n)[c])
    x = pd.concat(out).dropna(); return dict(n=int(x.size), mean=float(x.mean()), hit=float((x > 0).mean()), sd=float(x.std()))
rsi_x = lambda d: xover(d.RSI, pd.Series(35, index=d.index))
recent = lambda c: c.rolling(3).max().astype(bool)
B["confirm"] = {
    "RSI crosses up 35 (alone)": pool_fwd(rsi_x),
    "+ Stochastic oversold (redundant)": pool_fwd(lambda d: rsi_x(d) & (d.StochK.rolling(3).min() < 25)),
    "+ Stoch + below lower BB (doubly redundant)": pool_fwd(lambda d: rsi_x(d) & (d.StochK.rolling(3).min() < 25) & (d.BBpctB.rolling(3).min() < 0.05)),
    "+ CCI below −100 (redundant)": pool_fwd(lambda d: rsi_x(d) & (d.CCI.rolling(3).min() < -100)),
    "+ OBV above its EMA (independent: volume)": pool_fwd(lambda d: rsi_x(d) & (d.OBV > d.OBVema)),
    "+ MFI rising (volume-weighted)": pool_fwd(lambda d: rsi_x(d) & (d.MFI > d.MFI.shift(3))),
    "+ Close above SMA200 (independent: trend)": pool_fwd(lambda d: rsi_x(d) & (d.Close > d.SMA200)),
}

B["cherry"] = dict(best=max(SYMS, key=lambda s: res[("A", s)]["CAGR"]), best_cagr=max(res[("A", s)]["CAGR"] for s in SYMS),
                   avg_cagr=float(np.mean([res[("A", s)]["CAGR"] for s in SYMS])), worst=min(SYMS, key=lambda s: res[("A", s)]["CAGR"]),
                   worst_cagr=min(res[("A", s)]["CAGR"] for s in SYMS))
cont = []
for s_ in SYMS:
    d = win(D[s_]); cont.append(pd.DataFrame({"RSI": d.RSI, "Stoch %K": d.StochK, "BB %B": d.BBpctB, "MACD hist/ATR": d.MACDhist / d.ATR,
        "Close−SMA20 /ATR": (d.Close - d.SMA20) / d.ATR, "EMA9−21 /ATR": (d.EMA9 - d.EMA21) / d.ATR, "+DI − −DI": d.PDI - d.NDI, "OBV−EMA /Vol": (d.OBV - d.OBVema) / d.VolAvg20,
        "Close−Supertrend /ATR": (d.Close - d.ST) / d.ATR, "CCI": d.CCI, "MFI": d.MFI, "Donchian position": (d.Close - d.DClo) / (d.DCup - d.DClo)}))
C = pd.concat(cont).corr(); R["value_corr"] = C.round(3).to_dict()
fig, ax = plt.subplots(figsize=(8, 6.6)); C8 = C.values; NC = len(C); im = ax.imshow(C8, cmap="RdBu_r", vmin=-1, vmax=1); ax.grid(False)
ax.set_xticks(range(NC), C.columns, rotation=35, ha='right', fontsize=7.2); ax.set_yticks(range(NC), C.columns, fontsize=7.2)
for i in range(NC):
    for j in range(NC): ax.text(j, i, f"{C8[i,j]:.2f}", ha="center", va="center", fontsize=6.3, color="white" if C8[i, j] > .6 else INK)
fig.colorbar(im, ax=ax, shrink=.85).set_label("Correlation of daily readings (7 stocks pooled)", fontsize=7.5)
ax.set_title("Exhibit 22. Confirmation bias: most 'confirmations' are the same price information re-labelled", fontsize=9.5); save(fig, "18_bias_confirm")

# (b) Overconfidence: in-sample optimisation vs out-of-sample
grid = list(itertools.product([25, 30, 35, 40, 45], [3, 5, 7, 10, 15]))
ov = []
for s in SYMS:
    d = D[s]; best = None
    for th, h in grid:
        sg = xover(d.RSI, pd.Series(th, index=d.index)) & (d.Close > d.SMA200)
        c, t = backtest(d, sg, h, "2015-01-01", "2021-12-31"); sh = stats(c, t)["Sharpe"]
        if len(t) < 5 or not np.isfinite(sh): continue
        if best is None or sh > best[0]: best = (sh, th, h, stats(c, t)["CAGR"], len(t))
    sg = xover(d.RSI, pd.Series(best[1], index=d.index)) & (d.Close > d.SMA200)
    c, t = backtest(d, sg, best[2], "2022-01-01", END); so = stats(c, t)
    cd, td = backtest(d, sig_A(d), 7, "2022-01-01", END); sd = stats(cd, td)
    ci, ti = backtest(d, sig_A(d), 7, "2015-01-01", "2021-12-31"); si = stats(ci, ti)
    ov.append(dict(default_is_sh=si["Sharpe"], sym=s, th=best[1], hold=best[2], is_sh=best[0], is_cagr=best[3], is_n=best[4], oos_n=so["Trades"], oos_sh=so["Sharpe"] if np.isfinite(so["Sharpe"]) else 0.0, oos_cagr=so["CAGR"], default_oos_sh=sd["Sharpe"]))
B["overconf"] = ov
# hot-hand: win rate after 3 consecutive wins vs otherwise, pooled over all strategy trades
seq = []
for (k, s), t in trades_all.items():
    w = (t.ret > 0).astype(int).values
    for i in range(3, len(w)): seq.append((w[i - 3:i].sum() == 3, w[i - 3:i].sum() == 0, w[i]))
seq = np.array(seq)
B["hothand"] = dict(after3w=float(seq[seq[:, 0] == 1, 2].mean()), n3w=int((seq[:, 0] == 1).sum()), after3l=float(seq[seq[:, 1] == 1, 2].mean()),
                    n3l=int((seq[:, 1] == 1).sum()), all=float(seq[:, 2].mean()), n=int(len(seq)))
_p = B["hothand"]["all"]; B["hothand"]["z3w"] = float((B["hothand"]["after3w"] - _p) / np.sqrt(_p * (1 - _p) / B["hothand"]["n3w"]))
fig, ax = plt.subplots(figsize=(8, 3.2)); xs = np.arange(7)
ax.bar(xs - .27, [o["is_sh"] for o in ov], .26, color=PAL[0], label="Tuned, in-sample 2015–21 (what the trader expects)")
ax.bar(xs, [o["oos_sh"] for o in ov], .26, color=PAL[1], label="Tuned, out-of-sample 2022–26 (what he gets)")
ax.bar(xs + .27, [o["default_oos_sh"] for o in ov], .26, color="#b9b8b2", label="Untuned default, out-of-sample")
ax.axhline(0, color=INK2, lw=.8); ax.set_xticks(xs, SYMS); ax.set_ylabel("Sharpe ratio"); ax.legend(fontsize=7.5, ncol=2, loc="upper center", bbox_to_anchor=(.5, -.1))
ax.set_title("Exhibit 23. Overconfidence: the in-sample Sharpe promised far more than any rule delivered after 2021"); save(fig, "19_bias_overconf")

# (c) Anchoring: breakeven anchor on losing trades (strategy B) + 52-week high proximity
anc = []
for s in SYMS:
    d = D[s].reset_index(drop=True); t = trades_all[("B", s)]
    for _, r in t.iterrows():
        xi = int(np.searchsorted(d.Date.values, r.exit))
        if r.ret >= 0: anc.append(dict(sym=s, disc=r.ret, anch=r.ret, extra=0, loser=False)); continue
        target = r.ep * (1 + 2 * COMM); j = xi; lim = min(xi + 250, len(d) - 1)
        while j < lim and d.Close.iloc[j] < target: j += 1
        px = d.Close.iloc[j] if d.Close.iloc[j] >= target else d.Close.iloc[lim]
        worst = d.Low.iloc[xi:j + 1].min() / r.ep - 1
        anc.append(dict(sym=s, disc=r.ret, anch=px / r.ep * (1 - COMM) ** 2 - 1, extra=j - xi, loser=True, worst=worst, recovered=bool(d.Close.iloc[j] >= target)))
A = pd.DataFrame(anc); L = A[A.loser]
B["anchor"] = dict(n_loss=int(len(L)), disc_mean=float(L.disc.mean()), anch_mean=float(L.anch.mean()), extra_days=float(L.extra.mean()),
                   unrec=float(1 - L.recovered.mean()), worst_mean=float(L.worst.mean()), worst_min=float(L.worst.min()),
                   cap_days_disc=float(15), ret_per_day_disc=float(L.disc.mean() / 15), ret_per_day_anch=float(L.anch.mean() / (15 + L.extra.mean())))
hb = []
for s in SYMS:
    d = D[s]; m = d.Date >= START; dist = d.Close / d.Hi52 - 1; f = fwd(d, 20)
    hb.append(pd.DataFrame({"dist": dist[m], "f": f[m]}))
H = pd.concat(hb).dropna(); bins = [-1, -.30, -.20, -.10, -.05, -.02, 0.001]
H["b"] = pd.cut(H.dist, bins, labels=["<−30%", "−30 to −20%", "−20 to −10%", "−10 to −5%", "−5 to −2%", "within 2%"])
hg = H.groupby("b").f.agg(["mean", "count", lambda x: (x > 0).mean()]); hg.columns = ["mean", "n", "hit"]
B["hi52"] = {str(i): dict(mean=float(r["mean"]), n=int(r.n), hit=float(r.hit)) for i, r in hg.iterrows()}
fig, (a1, a2) = plt.subplots(1, 2, figsize=(8, 3.2), gridspec_kw={"width_ratios": [1, 1.3]})
a1.bar([0, 1, 2], [L.disc.mean() * 100, L.anch.mean() * 100, L.worst.mean() * 100], color=[PAL[0], PAL[1], PAL[7]], width=.55)
for i_, v_ in enumerate([L.disc.mean(), L.anch.mean(), L.worst.mean()]): a1.text(i_, v_ * 100 - .9, f"{v_*100:.1f}%", ha="center", fontsize=7.5, color=INK)
a1.set_xticks([0, 1, 2], ["Disciplined:\nexit day 15", "Anchored:\nfinal result", "Anchored:\nworst point\nwhile waiting"], fontsize=7)
a1.axhline(0, color=INK2, lw=.8)
a1.set_ylabel("Avg return, losing trades, %"); a1.set_title("Breakeven anchor (Strategy B losers)", fontsize=9)
a2.bar(range(len(hg)), hg["mean"] * 100, color=PAL[2], width=.6); a2.set_xticks(range(len(hg)), hg.index, fontsize=7, rotation=20)
a2.set_ylabel("Avg 20-day fwd return, %"); a2.set_title("Distance from 52-week high", fontsize=9)
fig.suptitle("Exhibit 24. Anchoring: to the entry price, and to the 52-week high", x=.01, ha="left", fontweight="bold", fontsize=10.5); save(fig, "20_bias_anchor")

# (d) Representativeness: 'overbought means sell' and 'golden cross means new bull market'
rep = {}
rep["RSI > 70 ('overbought')"] = pool_fwd(lambda d: xover(d.RSI, pd.Series(70, index=d.index)), 20)
rep["RSI < 30 ('oversold')"] = pool_fwd(lambda d: xunder(d.RSI, pd.Series(30, index=d.index)), 20)
rep["Unconditional (any day)"] = pool_fwd(lambda d: pd.Series(True, index=d.index), 20)
rep["Golden cross 50/200, 60d"] = pool_fwd(lambda d: xover(d.SMA50, d.SMA200), 60)
rep["Unconditional, 60d"] = pool_fwd(lambda d: pd.Series(True, index=d.index), 60)
rep["3 up-closes in a row, 5d"] = pool_fwd(lambda d: (d.Close.diff() > 0).rolling(3).sum() == 3, 5)
rep["Unconditional, 5d"] = pool_fwd(lambda d: pd.Series(True, index=d.index), 5)
B["repr"] = rep
# small-sample illusion: first-5-trade win rate vs full sample, strategy C
ss = [dict(sym=s, first5=float((trades_all[("C", s)].ret.head(5) > 0).mean()), full=float((trades_all[("C", s)].ret > 0).mean()), n=len(trades_all[("C", s)])) for s in SYMS]
B["smallsample"] = ss
fig, ax = plt.subplots(figsize=(8, 3.1)); lab = ["RSI>70\n'overbought'\n(20-day fwd)", "RSI<30\n'oversold'\n(20-day fwd)", "Any day\n(20-day fwd)", "", "Golden cross\n50/200\n(60-day fwd)", "Any day\n(60-day fwd)"]
vals = [rep["RSI > 70 ('overbought')"]["mean"], rep["RSI < 30 ('oversold')"]["mean"], rep["Unconditional (any day)"]["mean"], np.nan, rep["Golden cross 50/200, 60d"]["mean"], rep["Unconditional, 60d"]["mean"]]
ax.bar(range(6), np.array(vals) * 100, color=[PAL[7], PAL[5], "#b9b8b2", "none", PAL[0], "#b9b8b2"], width=.6)
for i, v in enumerate(vals):
    if not np.isnan(v): ax.text(i, v * 100 + .1, f"{v*100:.2f}%", ha="center", fontsize=7.5, color=INK)
ax.set_xticks(range(6), lab, fontsize=8); ax.set_ylabel("Avg forward return, %"); ax.axhline(0, color=INK2, lw=.8)
ax.set_title("Exhibit 25. Representativeness: textbook patterns vs. what actually followed (7 stocks pooled)"); save(fig, "21_bias_repr")

# (e) Recency: chase last quarter's best strategy vs fixed equal mix
rec = []
for s in SYMS:
    rr = pd.concat([curves[(k, s)].pct_change() for k in "ABC"], axis=1).fillna(0); rr.columns = list("ABC")
    mon = rr.resample("ME").apply(lambda x: (1 + x).prod() - 1)
    trail = (1 + mon).rolling(3).apply(np.prod, raw=True).shift(1).dropna(); pick = trail.idxmax(axis=1)
    chase = pd.Series([mon.loc[i, pick[i]] for i in pick.index], index=pick.index)
    mix = mon.mean(axis=1).loc[chase.index]
    sw = (pick.loc[chase.index] != pick.loc[chase.index].shift()).sum()
    rec.append(dict(sym=s, chase=float((1 + chase).prod() ** (12 / len(chase)) - 1), mix=float((1 + mix).prod() ** (12 / len(mix)) - 1),
                    chase_sh=float((chase - RF / 12).mean() / chase.std() * np.sqrt(12)), mix_sh=float((mix - RF / 12).mean() / mix.std() * np.sqrt(12)), switches=int(sw), months=len(chase)))
    if s == "RELIANCE": rec_curves = ((1 + chase).cumprod(), (1 + mix).cumprod())
B["recency"] = rec
# recency in indicator lookback: whipsaws of fast vs slow crossovers
wh = []
for s in SYMS:
    d = win(D[s])
    for nm, a, b in (("EMA 5/10", d.Close.ewm(span=5, adjust=False).mean(), d.Close.ewm(span=10, adjust=False).mean()), ("EMA 9/21", d.EMA9, d.EMA21), ("SMA 50/200", d.SMA50, d.SMA200)):
        wh.append(dict(sym=s, pair=nm, crosses_per_yr=float((xover(a, b) | xunder(a, b)).sum() / ((d.Date.iloc[-1] - d.Date.iloc[0]).days / 365.25))))
B["whipsaw"] = pd.DataFrame(wh).groupby("pair").crosses_per_yr.mean().to_dict()
fig, (a1, a2) = plt.subplots(1, 2, figsize=(8, 3.1))
a1.bar(np.arange(7) - .2, [r["chase"] * 100 for r in rec], .38, color=PAL[1], label="Chase last 3 months' winner")
a1.bar(np.arange(7) + .2, [r["mix"] * 100 for r in rec], .38, color=PAL[0], label="Fixed 1/3 each of A, B, C")
a1.set_xticks(range(7), SYMS, rotation=45, fontsize=7); a1.set_ylabel("CAGR, %"); a1.legend(fontsize=6.8); a1.axhline(0, color=INK2, lw=.8)
a2.plot(rec_curves[0], color=PAL[1], label="Chase (RELIANCE)"); a2.plot(rec_curves[1], color=PAL[0], label="Fixed mix (RELIANCE)"); a2.legend(fontsize=7); a2.set_ylabel("Growth of ₹1")
fig.suptitle("Exhibit 26. Recency bias: switching to whichever strategy 'worked lately'", x=.01, ha="left", fontweight="bold", fontsize=10.5); save(fig, "22_bias_recency")

# (f) Conservatism: COVID-2020 crash — how long each trend rule took to update
cons = []
for s in SYMS:
    d = win(D[s], "2019-10-01", "2020-12-31").reset_index(drop=True)
    pk = d.Close.loc[(d.Date >= "2020-01-01") & (d.Date <= "2020-02-21")].idxmax(); p0 = d.Close[pk]
    row = dict(sym=s, peak=str(d.Date[pk].date()), trough_dd=float(d.Close[pk:].loc[d.Date <= "2020-06-30"].min() / p0 - 1))
    for nm, cond in (("EMA 9/21 bearish", d.EMA9 < d.EMA21), ("Supertrend flips down", d.STdir == 1), ("Close < SMA 200", d.Close < d.SMA200), ("SMA 50/200 death cross", d.SMA50 < d.SMA200)):
        if cond.iloc[pk]: row[nm + "_days"] = None; row[nm + "_dd"] = None; row[nm + "_already"] = True; continue
        idx = cond[pk:]; j = idx[idx].index.min()
        row[nm + "_days"] = int(j - pk); row[nm + "_dd"] = float(d.Close[j] / p0 - 1); row[nm + "_already"] = False
    cons.append(row)
B["conserv"] = cons
d = win(D["HDFCBANK"], "2019-11-01", "2020-12-31")
fig, ax = plt.subplots(figsize=(8, 3.3)); ax.plot(d.Date, d.Close, color=INK2, lw=1, label="Close")
ax.plot(d.Date, d.EMA21, color=PAL[0], lw=1, label="EMA 21 (fast)"); ax.plot(d.Date, d.SMA50, color=PAL[1], lw=1, label="SMA 50"); ax.plot(d.Date, d.SMA200, color=PAL[6], lw=1, label="SMA 200 (slow)")
r = [c for c in cons if c["sym"] == "HDFCBANK"][0]
for nm, col in (("EMA 9/21 bearish", PAL[0]), ("SMA 50/200 death cross", PAL[6])):
    if r[nm + "_days"] is None: continue
    dd = d.reset_index(drop=True); pk = dd.Date.searchsorted(np.datetime64(r["peak"])); j = pk + r[nm + "_days"]
    ax.axvline(dd.Date.iloc[j], color=col, lw=.9, ls="--"); ax.text(dd.Date.iloc[j], dd.Close.max() * (.98 if "EMA" in nm else .80), f" {nm}\n {r[nm+'_days']} sessions after peak", fontsize=6.8, color=INK, va="top")
ax.legend(fontsize=7, ncol=4, loc="lower left"); ax.set_ylabel("₹")
ax.set_title("Exhibit 27. Conservatism: slow rules (and slow minds) update late — NSE:HDFCBANK, COVID-2020"); save(fig, "23_bias_conserv")

# (g) Herding: crowded signals + volume-spike breakouts
herd = {}
sigm = pd.concat({s: sig_B(D[s]).set_axis(D[s].Date) for s in SYMS}, axis=1).fillna(False)
bstate = pd.concat({s: ((D[s].EMA9 > D[s].EMA21) & (D[s].MACD > D[s].MACDsig)).set_axis(D[s].Date) for s in SYMS}, axis=1).fillna(False)
cnt_w = bstate.sum(axis=1)  # how many of the 7 are in the same bullish state that day
hh = []
for s in SYMS:
    d = D[s].set_index("Date"); f = fwd(D[s], 15).set_axis(D[s].Date); sg = sigm[s] & (sigm.index >= START)
    for dt in sg[sg].index: hh.append(dict(crowd=int(cnt_w.loc[dt]), f=f.loc[dt]))
Hh = pd.DataFrame(hh).dropna(); Hh["grp"] = pd.cut(Hh.crowd, [0, 3, 5, 7], labels=["Isolated (≤3 of 7)", "Moderate (4–5 of 7)", "Crowded (6–7 of 7)"])
herd["concurrency"] = {str(k): dict(n=int(len(g)), mean=float(g.f.mean()), hit=float((g.f > 0).mean())) for k, g in Hh.groupby("grp")}
herd["volspike"] = pool_fwd(lambda d: (d.Volume > 2 * d.VolAvg20) & (d.Close.pct_change() > 0.03), 20)
herd["volspike5"] = pool_fwd(lambda d: (d.Volume > 2 * d.VolAvg20) & (d.Close.pct_change() > 0.03), 5)
herd["uncond20"] = rep["Unconditional (any day)"]
herd["donch5"] = pool_fwd(lambda d: xover(d.Close, d.DCup.shift()), 5); herd["donch20"] = pool_fwd(lambda d: xover(d.Close, d.DCup.shift()), 20)
B["herd"] = herd
fig, (a1, a2) = plt.subplots(1, 2, figsize=(8, 3.1))
g = herd["concurrency"]; a1.bar(range(3), [g[k]["mean"] * 100 for k in g], color=[PAL[0], PAL[3], PAL[7]], width=.55)
a1.set_ylabel("Avg 15-day fwd return, %"); a1.set_title("Strategy B signals by how many of the 7 agree", fontsize=9)
a1.axhline(0, color=INK2, lw=.8); a1.set_xticks(range(3), [k.replace(" (", "\n(") + f"\nn={g[k]['n']}" for k in g], fontsize=7)
a2.bar(range(4), [herd["volspike5"]["mean"] * 100, rep["Unconditional, 5d"]["mean"] * 100, herd["volspike"]["mean"] * 100, herd["uncond20"]["mean"] * 100], color=[PAL[1], "#b9b8b2", PAL[1], "#b9b8b2"], width=.55)
a2.set_xticks(range(4), ["Vol-spike\nbreakout\n5-day", "Any day\n5-day", "Vol-spike\nbreakout\n20-day", "Any day\n20-day"], fontsize=7); a2.axhline(0, color=INK2, lw=.8); a2.set_ylabel("Avg fwd return, %"); a2.set_title("Joining a high-volume breakout", fontsize=9)
fig.suptitle("Exhibit 28. Herding: following the crowd into the same signal", x=.01, ha="left", fontweight="bold", fontsize=10.5); save(fig, "24_bias_herd")

# (h) FOMO: late entry delay + chasing extended prices
fomo = {}
for k in "BC":
    rowd = {}
    for dl in (0, 2, 5, 10):
        cg = []
        for s in SYMS:
            c, t = backtest(D[s], STRATS[k][1](D[s]), STRATS[k][2], delay=dl); cg.append(t.ret.mean())
        rowd[dl] = float(np.mean(cg))
    fomo[k] = rowd
ext = []
for s in SYMS:
    d = D[s]; t = trades_all[("B", s)].copy(); dd = d.set_index("Date")
    for _, r in t.iterrows():
        i = d.index[d.Date == r.entry][0] - 1; ext.append(dict(ret=r.ret, ext=(d.Close[i] - d.EMA21[i]) / d.ATR[i], rsi=d.RSI[i]))
E = pd.DataFrame(ext); E["chase"] = (E.ext > 1.5) | (E.rsi > 70)
fomo["extended"] = dict(chase_n=int(E.chase.sum()), chase_mean=float(E[E.chase].ret.mean()), chase_hit=float((E[E.chase].ret > 0).mean()),
                        norm_n=int((~E.chase).sum()), norm_mean=float(E[~E.chase].ret.mean()), norm_hit=float((E[~E.chase].ret > 0).mean()))
B["fomo"] = fomo
fig, (a1, a2) = plt.subplots(1, 2, figsize=(8, 3.1))
for k, c in (("B", PAL[1]), ("C", PAL[2])):
    a1.plot([0, 2, 5, 10], [fomo[k][x] * 100 for x in (0, 2, 5, 10)], marker="o", ms=5, color=c, label=f"Strategy {k}")
a1.set_xlabel("Entry delay after signal (trading days)"); a1.set_ylabel("Avg return per trade, %"); a1.legend(fontsize=7); a1.set_title("Late entry ('it's already running')", fontsize=9)
a2.bar([0, 1], [E[~E.chase].ret.mean() * 100, E[E.chase].ret.mean() * 100], color=[PAL[0], PAL[7]], width=.5)
a2.set_xticks([0, 1], [f"Normal entry\n(n={int((~E.chase).sum())})", f"Extended entry\n>1.5 ATR or RSI>70 (n={int(E.chase.sum())})"], fontsize=7)
a2.set_ylabel("Avg return per trade, %"); a2.set_title("Strategy B trades by entry extension", fontsize=9); a2.axhline(0, color=INK2, lw=.8)
fig.suptitle("Exhibit 29. FOMO: chasing late and chasing extended prices", x=.01, ha="left", fontweight="bold", fontsize=10.5); save(fig, "25_bias_fomo")
B["confirm_corr"] = dict(rsi_stoch=float(C.loc["RSI","Stoch %K"]), rsi_bb=float(C.loc["RSI","BB %B"]), rsi_obv=float(C.loc["RSI","OBV−EMA /Vol"]), rsi_dmi=float(C.loc["RSI","+DI − −DI"]),
    rsi_cci=float(C.loc["RSI","CCI"]), rsi_mfi=float(C.loc["RSI","MFI"]), rsi_st=float(C.loc["RSI","Close−Supertrend /ATR"]), rsi_dc=float(C.loc["RSI","Donchian position"]))
# ---- significance of every bias comparison (Welch t on means, two-proportion z on hit rates) ----
def tdiff(x, y): return float((x["mean"] - y["mean"]) / np.sqrt(x["sd"] ** 2 / x["n"] + y["sd"] ** 2 / y["n"]))
def zhit(x, y):
    p = (x["hit"] * x["n"] + y["hit"] * y["n"]) / (x["n"] + y["n"]); return float((x["hit"] - y["hit"]) / np.sqrt(p * (1 - p) * (1 / x["n"] + 1 / y["n"])))
k0 = B["confirm"]["RSI crosses up 35 (alone)"]
B["confirm_tests"] = {k: dict(z_hit=zhit(v, k0), t_mean=tdiff(v, k0)) for k, v in B["confirm"].items() if k != "RSI crosses up 35 (alone)"}
rp = B["repr"]
B["repr_tests"] = {"RSI > 70 ('overbought')": tdiff(rp["RSI > 70 ('overbought')"], rp["Unconditional (any day)"]), "RSI < 30 ('oversold')": tdiff(rp["RSI < 30 ('oversold')"], rp["Unconditional (any day)"]),
                   "Golden cross 50/200, 60d": tdiff(rp["Golden cross 50/200, 60d"], rp["Unconditional, 60d"]), "3 up-closes in a row, 5d": tdiff(rp["3 up-closes in a row, 5d"], rp["Unconditional, 5d"])}
hd = B["herd"]
B["herd_tests"] = dict(volspike5=tdiff(hd["volspike5"], rp["Unconditional, 5d"]), volspike20=tdiff(hd["volspike"], hd["uncond20"]),
                       donch5=tdiff(hd["donch5"], rp["Unconditional, 5d"]), donch20=tdiff(hd["donch20"], hd["uncond20"]))
_cr = hd["concurrency"]["Crowded (6–7 of 7)"]; _iso = hd["concurrency"]["Isolated (≤3 of 7)"]
B["herd_tests"]["crowd_vs_iso_z"] = zhit(_cr, _iso)
# FOMO: trade-level t for C, on-signal vs 10 days late
_r0, _r10 = [], []
for s in SYMS:
    _r0.append(backtest(D[s], sig_C(D[s]), 60, delay=0)[1].ret); _r10.append(backtest(D[s], sig_C(D[s]), 60, delay=10)[1].ret)
_r0, _r10 = pd.concat(_r0), pd.concat(_r10)
B["fomo"]["C_t"] = float((_r0.mean() - _r10.mean()) / np.sqrt(_r0.var() / len(_r0) + _r10.var() / len(_r10))); B["fomo"]["C_n"] = int(len(_r0))
# anchoring: paired t on losing trades (anchored final vs disciplined)
B["anchor"]["t_paired"] = float((L.anch - L.disc).mean() / ((L.anch - L.disc).std() / np.sqrt(len(L))))
R["bias"] = B

# ================= 4. mitigation: pre-registered candidates, chosen in-sample, judged out-of-sample =================
def anti_fomo(d): return ~(((d.Close - d.EMA21) / d.ATR > 1.5) | (d.RSI > 70))
def vol_conf(d): return d.OBV > d.OBVema
STOPM = {"A": 2.0, "B": 3.0, "C": 4.0}
CANDS = {"M0 Naive (as built)": lambda k, d: dict(),
         "M1 Horizon-scaled ATR stop": lambda k, d: dict(stop_atr=STOPM[k]),
         "M2 Anti-FOMO entry filter": lambda k, d: dict(entry_filter=anti_fomo(d)),
         "M3 Independent volume confirmation": lambda k, d: dict(entry_filter=vol_conf(d)),
         "M4 ATR stop + volume confirmation": lambda k, d: dict(stop_atr=STOPM[k], entry_filter=vol_conf(d)),
         "M5 Supertrend trailing exit": lambda k, d: dict(exit_signal=(d.STdir == 1))}
def run_port(k, cand, a, b):
    cs, dds, ts = [], [], []
    for s in SYMS:
        d = D[s]; c, t = backtest(d, STRATS[k][1](d), STRATS[k][2], a, b, **CANDS[cand](k, d))
        cs.append(c / CAPITAL); dds.append(stats(c, t)["MaxDD"]); ts.append(t)
    pc = pd.concat(cs, axis=1).ffill().mean(axis=1) * CAPITAL; st = stats(pc, pd.concat(ts))
    return pc, dict(cagr=st["CAGR"], sharpe=st["Sharpe"], se=st["SharpeSE"], dd=st["MaxDD"], avg_stock_dd=float(np.mean(dds)), worst_stock_dd=float(min(dds)),
                    trades=int(st["Trades"]), win=float(st["Win"]) if st["Trades"] else None)
mit = {}; chosen = {}; pcs = {}
for k in "ABC":
    for cand in CANDS:
        _, is_ = run_port(k, cand, "2015-01-01", "2021-12-31"); _, oos = run_port(k, cand, "2022-01-01", END); pc, full = run_port(k, cand, START, END)
        mit[f"{k}|{cand}"] = dict(IS=is_, OOS=oos, FULL=full); pcs[(k, cand)] = pc
    chosen[k] = max(CANDS, key=lambda c: mit[f"{k}|{c}"]["IS"]["sharpe"])
R["mitig"] = mit; R["mitig_chosen"] = chosen
# diversification across the 21 strategy-stock sleeves
naive_all = pd.concat([pcs[(k, "M0 Naive (as built)")] for k in "ABC"], axis=1).mean(axis=1)
disc_all = pd.concat([pcs[(k, chosen[k])] for k in "ABC"], axis=1).mean(axis=1)
R["diversified"] = dict(naive=stats(naive_all, pd.DataFrame()), disciplined=stats(disc_all, pd.DataFrame()))
# out-of-sample only: the only honest test of rules chosen on 2015-21
oo = {}
oo["naive"] = pd.concat([run_port(k, "M0 Naive (as built)", "2022-01-01", END)[0] for k in "ABC"], axis=1).mean(axis=1)
oo["disciplined"] = pd.concat([run_port(k, chosen[k], "2022-01-01", END)[0] for k in "ABC"], axis=1).mean(axis=1)
for k in "ABC": oo[f"{k}_chosen"] = run_port(k, chosen[k], "2022-01-01", END)[0]
oo["BH"] = pd.concat([buyhold(D[s], "2022-01-01", END) for s in SYMS], axis=1).ffill().mean(axis=1)
_is = {}
_is["BH"] = pd.concat([buyhold(D[s], "2015-01-01", "2021-12-31") for s in SYMS], axis=1).ffill().mean(axis=1)
_is["disciplined"] = pd.concat([run_port(k, chosen[k], "2015-01-01", "2021-12-31")[0] for k in "ABC"], axis=1).mean(axis=1)
R["oos"] = {k: stats(v, pd.DataFrame()) for k, v in oo.items()}
R["is_"] = {k: stats(v, pd.DataFrame()) for k, v in _is.items()}
R["port_full_BH"] = stats(port["BH"], pd.DataFrame())
# robustness grid: cost per side x cash rate, full sample and OOS, naive strategies + buy-and-hold
import engine as EN
rob = []
for cst in (0.0005, 0.0015, 0.0025):
    for rf_ in (0.0, 0.06):
        EN.COMM, EN.RF = cst, rf_
        for k in ["A", "B", "C", "BH"]:
            for lab, a_, b_ in (("FULL", START, END), ("OOS", "2022-01-01", END)):
                if k == "BH": pc = pd.concat([buyhold(D[s], a_, b_) for s in SYMS], axis=1).ffill().mean(axis=1)
                else: pc = pd.concat([backtest(D[s], STRATS[k][1](D[s]), STRATS[k][2], a_, b_)[0] for s in SYMS], axis=1).ffill().mean(axis=1)
                st_ = stats(pc, pd.DataFrame(), rf=rf_)
                rob.append(dict(cost=cst, rf=rf_, strat=k, period=lab, sharpe=st_["Sharpe"], cagr=st_["CAGR"], dd=st_["MaxDD"]))
EN.COMM, EN.RF = 0.0015, 0.06
R["robust"] = rob
fig, axs = plt.subplots(1, 3, figsize=(8, 3.1))
for a, k in zip(axs, "ABC"):
    for cand in CANDS:
        if cand != chosen[k]: a.plot(pcs[(k, cand)] / CAPITAL, color="#c9c8c2", lw=.8)
    a.plot(pcs[(k, chosen[k])] / CAPITAL, color=[PAL[0], PAL[1], PAL[2]]["ABC".index(k)], lw=1.6, label="Chosen on 2015–21: " + chosen[k].split(" ")[0])
    a.plot([], [], color="#c9c8c2", lw=.8, label="Other candidates M0–M5")
    a.axvline(pd.Timestamp("2022-01-01"), color=INK2, lw=.8, ls="--")
    a.set_title(f"Strategy {k}  (OOS after dashed line)", fontsize=8.5); a.legend(fontsize=6.2, loc="lower right"); a.xaxis.set_major_locator(mdates.YearLocator(4)); a.xaxis.set_major_formatter(mdates.DateFormatter("%Y"))
axs[0].set_ylabel("Growth of ₹1 (EW 7 stocks)")
fig.suptitle("Exhibit 30. Mitigation: rule chosen on 2015–21 only, then judged on unseen 2022–26", x=.01, ha="left", fontweight="bold", fontsize=10.5); save(fig, "26_mitigation")
fig, ax = plt.subplots(figsize=(8, 2.9))
for k, c, lab in (("BH", "#b9b8b2", "Buy-and-hold (EW 7)"), ("C_chosen", PAL[2], "Strategy C alone"), ("disciplined", PAL[0], "All 21 sleeves, disciplined"), ("naive", PAL[3], "All 21 sleeves, naive")):
    ax.plot(oo[k] / oo[k].iloc[0], color=c, lw=1.6 if k == "C_chosen" else 1.1, label=f"{lab}: Sharpe {R['oos'][k]['Sharpe']:.2f}, max DD {R['oos'][k]['MaxDD']*100:.0f}%")
ax.legend(fontsize=7, ncol=2, loc="upper center", bbox_to_anchor=(.5, -.1)); ax.set_ylabel("Growth of ₹1 (Jan 2022 = 1)")
ax.set_title("Exhibit 31. Out-of-sample only (2022–26): the pre-registered 60-day rule did best per unit of risk"); save(fig, "27_diversified")

json.dump(R, open("/home/claude/tav/results.json", "w"), default=lambda o: float(o) if isinstance(o, (np.floating, np.integer)) else str(o), indent=1)
# trade logs
pd.concat([t.assign(strategy=k, symbol=s) for (k, s), t in trades_all.items()]).to_csv("/home/claude/tav/trade_log.csv", index=False)
print("done")
